import os
# from underdogcowboy.core.specializedagents.commit_promo_agent import CommitPromoAgent
# from underdogcowboy.core.specializedagents.type_setter_agent import TypeSetterAgent
# from underdogcowboy.core.specializedagents.assessment_tester import AssessmentTestAgent
# from underdogcowboy.core.specializedagents.compress_agent import CompressAgent


SPECIALIZED_AGENTS = {
  #  "commit_promo": CommitPromoAgent,
  #  "type_maker": TypeSetterAgent,
  #  "assessment_tester" : AssessmentTestAgent,
  #  "compress_tester" : CompressAgent, 
  # Add more mappings here for other specialized agents
}